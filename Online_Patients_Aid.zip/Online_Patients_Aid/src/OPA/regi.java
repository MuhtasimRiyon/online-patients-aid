package OPA;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class regi extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private JTextField textField_1;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					regi frame = new regi();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public regi() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(537, 150, 300, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegistration = new JLabel("Registration");
		lblRegistration.setBounds(108, 11, 76, 22);
		lblRegistration.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblRegistration);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(10, 61, 76, 14);
		contentPane.add(lblEmail);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(10, 98, 76, 14);
		contentPane.add(lblPassword);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setBounds(10, 134, 76, 14);
		contentPane.add(lblGender);
		
		JLabel lblAge = new JLabel("Age");
		lblAge.setBounds(10, 189, 76, 14);
		contentPane.add(lblAge);
		
		JButton btnConfirm = new JButton("Confirm");
		btnConfirm.setBounds(10, 227, 89, 23);
		btnConfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String E = textField.getText().toString();
				String P = passwordField.getText().toString();
				String G = comboBox.getSelectedItem().toString();
				String A = textField_1.getText().toString();
				
				if(E.equals("")) {
					JOptionPane.showMessageDialog(null,"Input Email");
				}else if (P.equals("")) {
					JOptionPane.showMessageDialog(null,"Input Password");
				}else if (G.equals("")) {
					JOptionPane.showMessageDialog(null,"Input Gender");
				}else if (A.equals("")) {
					JOptionPane.showMessageDialog(null,"Input Age");
				}else {

					try {
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/regi","root","");
						String sql = "INSERT INTO `regi` (`Email`, `Password`, `Gender`, `Age`) VALUES (?, ?, ?, ?) ";
						PreparedStatement pstat = con.prepareStatement(sql);
						pstat.setString(1,E);
						pstat.setString(2,P);
						pstat.setString(3,G);
						pstat.setString(4,A);
						if(pstat.executeUpdate() > 0) {
							JOptionPane.showMessageDialog(null,"Registration Successful");
						}
						//pstat.executeUpdate();
						//JOptionPane.showMessageDialog(null,"Registration Successful");
						
					}catch(SQLException e1) {
						System.out.println(e1);
					}
				}
			}
		});
		contentPane.add(btnConfirm);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setBounds(185, 227, 89, 23);
		contentPane.add(btnExit);
		
		textField = new JTextField();
		textField.setBounds(130, 58, 144, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(131, 95, 143, 20);
		contentPane.add(passwordField);
		
		textField_1 = new JTextField();
		textField_1.setBounds(131, 186, 143, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
		comboBox.setMaximumRowCount(2);
		comboBox.setBounds(130, 141, 144, 22);
		contentPane.add(comboBox);
	}
}
