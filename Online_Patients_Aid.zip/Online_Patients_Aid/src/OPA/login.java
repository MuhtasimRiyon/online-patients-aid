package OPA;

import java.awt.EventQueue;
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.sql.*;
import officemanagementsystem.MENUPAGE;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

public class login {

	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;

	/*
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login window = new login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/*
	 * Create the application.
	 */
	public login() {
		initialize();
	}

	/*
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(500, 150, 375, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnSingup = new JButton("Singup");
		btnSingup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				regi regi = new regi();
				regi.setVisible(true);
			}
		});
		btnSingup.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnSingup);
		
		JButton btnSingin = new JButton("Singin");
		btnSingin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/regi","root","");
					Statement stat = con.createStatement();
					String sql = "Select * from regi where Email='"+textField.getText()+"' and Password ='"+passwordField.getText().toString()+"'";
					ResultSet rs = stat.executeQuery(sql);
					if(rs.next()) {
						MENUPAGE menu = new MENUPAGE();
						menu.setVisible(true);
					}else {
						JOptionPane.showMessageDialog(null,"Invalid Login Details","Login Error",JOptionPane.ERROR_MESSAGE);
						passwordField.setText(null);
						textField.setText(null);
					}
				}catch(Exception e1) {
					System.out.println(e1);
				}
			}
		});
		btnSingin.setBounds(158, 227, 89, 23);
		frame.getContentPane().add(btnSingin);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setBounds(258, 227, 89, 23);
		frame.getContentPane().add(btnExit);
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogin.setBounds(135, 11, 89, 23);
		frame.getContentPane().add(lblLogin);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(10, 51, 89, 23);
		frame.getContentPane().add(lblEmail);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(10, 125, 89, 14);
		frame.getContentPane().add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(158, 52, 189, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(158, 122, 189, 20);
		frame.getContentPane().add(passwordField);
	}
}
